python runtime_CLI.py < commands.txt
